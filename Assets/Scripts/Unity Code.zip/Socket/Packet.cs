﻿using System;

[Serializable]
public struct Packet {

	public int type;
	public string message;

}